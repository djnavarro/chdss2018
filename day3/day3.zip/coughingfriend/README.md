# Coughing Friend Example

A simple example to introduce Bayesian inference. You observe your friend coughing: do you think he has a cold, emphysema, or a stomach upset?


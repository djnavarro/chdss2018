# The Foodweb problem

We used the foodweb problem to introduce Bayesian networks (also known as Directed Graphical Models).

foodweb.R carries out inference over a Bayesian network by either enumerating the entire hypothesis space or sampling from the prior P(h)

foodweb_JAGS.R carries out inference by using a program called JAGS to sample directly from the posterior distribution P(h|obs)





# The Number Game

Code for a simple variant of Josh Tenenbaum's number game. We'll look at 4 
models that represent all possible combinations of two priors (maths prior and uniform prior) and two likelihoods (strong and weak sampling). 


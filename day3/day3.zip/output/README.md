# Plots

Plots for the coughing friend, number game and foodweb examples will go here 



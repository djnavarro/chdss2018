Project folder for the Hayes et al. work on sampling frames

- experiments: could put code for running the experiment here

- analysis: could put code for analyzing the data here

- model: contains code implementing the model proposed by Hayes et al

